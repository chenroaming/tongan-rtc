module.exports = {
  ENV: '"development"',
  NODE_ENV: '"development"',
  DEBUG_MODE: true,
  API_KEY: '"XXXX-XXXXX-XXXX-XXXX"'
}
