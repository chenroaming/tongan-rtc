module.exports = {
  ENV: '"production"',
  NODE_ENV: '"production"',
  DEBUG_MODE: false,
  API_KEY: '"XXXX-XXXXX-XXXX-XXXX"'
}
