import * as QNRTC from 'pili-rtc-web'

export const piliRTC = new QNRTC.QNRTCSession()
