import HZRecorder from './recorder-worker.js'

export {
  HZRecorder
}