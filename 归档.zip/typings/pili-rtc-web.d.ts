declare module 'pili-rtc-web'
