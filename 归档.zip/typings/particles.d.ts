declare module 'particles.js'
declare var particlesJS: Function
