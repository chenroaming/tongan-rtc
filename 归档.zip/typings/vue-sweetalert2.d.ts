declare module 'vue-sweetalert2'
